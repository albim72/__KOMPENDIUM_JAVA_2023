public class Main {
    public static void main(String[] args) {

        int[] tablica = new int[10];

        for(int i=0; i<10;i++)
            tablica[i] = i+1;

        int zmienna = tablica[3];
        System.out.println("wybrana komorka to: " + zmienna);

        for(int i=0; i<10;i++)
            System.out.println("kolejna komórka to: " + tablica[i]);
    }
}