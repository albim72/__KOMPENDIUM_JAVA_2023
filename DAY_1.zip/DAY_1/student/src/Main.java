public class Main {
    public static void main(String[] args) {

        Osoba os1 = new Osoba("Aneta","Grech","Kraków",34);
        System.out.println(os1);
        os1.printOsoba();

        Student st1 = new Student("Olaf","Kowal","Lublin",23,
                "R5445","UMCS","Informatyka");

        st1.printOsoba();


        Osoba st2 = new Student("Olaf","Kowal","Lublin",23,
                "R5445","UMCS","Informatyka");
        st2.printOsoba();

        Osoba st3 = (Osoba)st1;
        st3.printOsoba();


    }
}