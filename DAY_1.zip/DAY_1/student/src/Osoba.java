public class Osoba {
    String imie;
    String nazwisko;
    String miejscowosc;
    Integer wiek;

    public Osoba(String imie, String nazwisko, String miejscowosc, Integer wiek) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.miejscowosc = miejscowosc;
        this.wiek = wiek;
    }

    public Osoba(String imie, String nazwisko, String miejscowosc) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.miejscowosc = miejscowosc;
    }

    public Osoba() {
    }

    public void printOsoba(){
        System.out.println("Osoba -> imię: "+ imie + ", nazwisko" + nazwisko + ", miasto: " + miejscowosc);

    }

}
