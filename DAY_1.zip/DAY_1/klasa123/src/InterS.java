public interface InterS {

    public void Opis();
    public int policz();
    public double wynik(int a, double h);

}
