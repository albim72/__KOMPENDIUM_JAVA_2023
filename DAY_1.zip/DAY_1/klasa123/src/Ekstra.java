public class Ekstra implements InterS{
    @Override
    public void Opis() {
        System.out.println("niezależna implementacja InterS");
    }

    @Override
    public int policz() {
        return 1000;
    }

    @Override
    public double wynik(int a, double h) {
        return a*h;
    }
}
