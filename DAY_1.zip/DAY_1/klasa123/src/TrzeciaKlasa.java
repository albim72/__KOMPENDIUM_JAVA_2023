public class TrzeciaKlasa extends DrugaKlasa implements InterS{
    int d;
    public TrzeciaKlasa(int a, int b, int c, int d) {
        super(a, b, c);
        this.d=d;
    }

    public String printABCD(){
        return "wartość a: " + a + "wartość b: " + b + "wartość c: " +c + "wartość d: " +d;
    }

    @Override
    public int suma() {
        return super.suma() + d;
    }

    @Override
    public void Opis() {
        System.out.println("to jest opisa Trzeicej Klasy");
    }

    @Override
    public int policz() {
        return 444;
    }

    @Override
    public double wynik(int a, double h) {
        return a*1/(2+h);
    }
}
