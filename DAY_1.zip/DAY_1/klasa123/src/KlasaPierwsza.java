public class KlasaPierwsza {
    int a;
    int b;

    public KlasaPierwsza(int a, int b) {
        this.a = a;
        this.b = b;
        this.info();
    }

    public void info(){
        System.out.println("powstał obiekt klasy KlasaPierwsza");
    }

    protected String printAB(){
        return "wartość a: " + a + "wartość b: " + b;
    }
}
