public class Main {
    public static void main(String[] args) {


        System.out.println("______________ Klasa Pierwsza ______________");
        KlasaPierwsza kp = new KlasaPierwsza(3,7);
        System.out.println(kp.printAB());

        System.out.println("______________ Klasa Druga ______________");

        DrugaKlasa dk = new DrugaKlasa(4,7,2);
        System.out.println(dk.printAB());
        System.out.println(dk.printABC());
        System.out.println(dk.suma());

        System.out.println("______________ Klasa Trzecia ______________");
        TrzeciaKlasa tk = new TrzeciaKlasa(2,9,8,3);
        System.out.println(tk.printAB());
        System.out.println(tk.printABC());
        System.out.println(tk.printABCD());
        System.out.println(tk.suma());
        tk.Opis();
        System.out.println(tk.policz());
        System.out.println(tk.wynik(7,8));

        System.out.println("______________ Klasa Ekstra ______________");

        Ekstra ek = new Ekstra();
        ek.Opis();
        System.out.println(ek.policz());
        System.out.println(ek.wynik(7,8));

        InterS iss = new Ekstra();
        iss.Opis();
        System.out.println(iss.policz());
        System.out.println(iss.wynik(7,8));

        InterS icc  = new TrzeciaKlasa(3,8,9,4);
        icc.Opis();
        System.out.println(icc.policz());
        System.out.println(icc.wynik(7,8));

    }
}