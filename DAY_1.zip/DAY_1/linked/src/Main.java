import java.util.LinkedList;
import java.util.Objects;

public class Main {
    public static void main(String[] args) {

        LinkedList<String> object = new LinkedList<>();
        object.add("A");
        object.add("B");

        object.addLast("C");
        object.addFirst("D");

        object.add(2,"E");
        object.add("F");
        object.add("K");
        System.out.println("Lista linkowana: " + object);

        boolean status = object.contains("E");
        if (status)
            System.out.println("Lista zawiera E");
        else
            System.out.println("Lista nie zawiera E");


        int size = object.size();
        System.out.println("liczba elementów: " + size);

        Object element  = object.get(2);
        System.out.println("element zwracany przez get(): " + element);
        object.set(4,"Y");
        System.out.println("lista po zamianie: " + object);
    }
}