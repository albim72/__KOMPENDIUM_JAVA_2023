public class Punkty {
    private int wspX;
    private int wspY;
    void  ustawX(int x){
        wspX = x;
    }

    void  ustawY(int y){
        wspY = y;
    }

    int pX(){
        return wspX;
    }
    int pY(){
        return wspY;
    }

}
