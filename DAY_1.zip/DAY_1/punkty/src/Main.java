public class Main {
    public static void main(String[] args) {
        Punkty pkt = new Punkty();
        pkt.ustawX(14);
        pkt.ustawY(7);

        System.out.println("wartość x: " + pkt.pX());
        System.out.println("wartość y: " + pkt.pY());

    }
}