import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int a = 5;
        double b = 13.5;
        double c = b/a;
        System.out.println(c);

        int v = 8;
        double k = (double)v/a;
        System.out.println(k);

        boolean g = true;

        Scanner in = new Scanner(System.in);
        System.out.println("Podaj liczbę całkowitą");
        int ax = in.nextInt();

        System.out.println("Podaj liczbę całkowitą");
        int bx = in.nextInt();

        int pot = (int) Math.pow(ax,bx);
        System.out.println(pot);

        System.out.println("podaj liczbę rzeczywistą: ");
        double hx = in.nextDouble();

        System.out.println(hx*100);




    }
}