public class Main {

    static <T> void genericDisp(T element)
    {
        System.out.println(element.getClass().getName() + " = " + element);
    }

    public static void main(String[] args) {
        genericDisp(345);
        genericDisp("blabla");
        genericDisp(5.66);

    }
}