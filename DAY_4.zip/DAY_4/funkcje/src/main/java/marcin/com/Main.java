package marcin.com;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class Main {
    public void printMessage(String message)
    {
        System.out.println(
                "you invoked me with the message:" + message);
    }

    public static void main(String[] args) throws Exception
    {
        System.out.println("Invoke method by Name in Java using Reflection!");

        // create class object to get its details
        Main obj = new Main();

        Class<?> classObj = obj.getClass();

        // get method object for "printMessage" function by
        // name
        Method printMessage = classObj.getDeclaredMethod("printMessage", String.class);

        try {

            // invoke the function using this class obj
            // pass in the class object
            printMessage.invoke(obj, "hello");
        }

        catch (InvocationTargetException e)
        {
            System.out.println(e.getCause());
        }
    }
}
