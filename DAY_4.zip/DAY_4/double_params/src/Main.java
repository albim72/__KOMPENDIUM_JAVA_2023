class Testowa<T,U>
{
    T obj1;
    U obj2;

    public Testowa(T obj1, U obj2) {
        this.obj1 = obj1;
        this.obj2 = obj2;
    }

    public void print()
    {
        System.out.println(obj1);
        System.out.println(obj2);
    }
}

public class Main {
    public static void main(String[] args) {

        Testowa<String,Integer> obj = new Testowa<>("ABC",345435);
        obj.print();
    }
}