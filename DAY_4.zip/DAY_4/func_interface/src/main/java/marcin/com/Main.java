package marcin.com;

public class Main {
    public static void main(String[] args) {
        int a = 6;
        Square s = (int x) -> x*x;
        int as = s.calculate(a);
        System.out.println(as);

        Square obw = (int x) -> 4*x;
        int obb = obw.calculate(a);
        System.out.println(obb);
    }
}
