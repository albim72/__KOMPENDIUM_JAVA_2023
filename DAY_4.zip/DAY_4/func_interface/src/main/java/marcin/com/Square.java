package marcin.com;

public interface Square {
    int calculate(int x);
}

