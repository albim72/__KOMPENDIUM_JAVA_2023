package marcin.com;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/dbtestowa";
        String user = "root";
        String password = "abc123";

        String query = "SELECT * FROM student";

        //String query = "SELECT VERSION()";

        try (Connection con = DriverManager.getConnection(url, user, password);
             Statement st = con.createStatement()) {
            String sql = "CREATE TABLE REGISTRATION " +
                    "(id INTEGER not NULL, " +
                    " first VARCHAR(255), " +
                    " last VARCHAR(255), " +
                    " age INTEGER, " +
                    " PRIMARY KEY ( id ))";

            st.executeUpdate(sql);
            System.out.println("Created table in given database...");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } ;


    }
}
