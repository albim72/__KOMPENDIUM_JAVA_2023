package marcin.com;

public interface IFunkcja {
    void absFunkcja(int x);
    default int normalFunkcja(int x, int y){return x+y;}
}
