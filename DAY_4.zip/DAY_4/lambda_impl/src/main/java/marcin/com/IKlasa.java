package marcin.com;

public class IKlasa implements IFunkcja{
    @Override
    public void absFunkcja(int x) {
        System.out.println(x+111);
    }
}
