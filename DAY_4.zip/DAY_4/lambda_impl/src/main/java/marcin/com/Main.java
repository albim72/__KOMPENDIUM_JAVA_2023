package marcin.com;

public class Main {
    public static void main(String[] args) {
        IFunkcja fobj1 = (int x) -> System.out.println("wynik = " + 2*x);
        fobj1.absFunkcja(5);
        fobj1.absFunkcja(105);
        IDruga nowaf = (int x, int y) -> System.out.println("wynik = " + (2*x+3*y));
        nowaf.drugaFunkcja(3,4);

        IKlasa ik = new IKlasa();
        ik.absFunkcja(77);
        System.out.println(ik.normalFunkcja(56,122));
    }
}
