package marcin.com;

public interface IDruga {
    void drugaFunkcja(int x, int y);
}
