package marcin.com;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> mojalista = new ArrayList<Integer>();
        mojalista.add(45);
        mojalista.add(11);
        mojalista.add(121);
        mojalista.add(6);
        mojalista.add(15);
        mojalista.add(89);
        mojalista.add(50);

        mojalista.forEach(n-> System.out.print(n+"\t"));
        System.out.println();

        System.out.println("______________________________________________");

        mojalista.forEach(n->{if(n%2==0) System.out.print(n+"\t");});

    }
}
