package marcin.com;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException, ParseException {

        JSONObject jo = new JSONObject();
        jo.put("firstName","Janek");
        jo.put("lastName","Kot");
        jo.put("age",45);

        Map m = new LinkedHashMap(4);

        m.put("streetAdr","ul.Złota 6");
        m.put("city","Kraków");
        m.put("woj","małopolskie");
        m.put("pcode","12887");

        jo.put("address",m);


        JSONArray ja = new JSONArray();
        m = new LinkedHashMap(2);
        m.put("type","domowy");
        m.put("number","423432678");

        ja.add(m);

        jo.put("phone",ja);

        PrintWriter pw = new PrintWriter("JSONosoby.json");
        pw.write(jo.toJSONString());
        pw.flush();
        pw.close();

        /**
         *
         * Parsowanie źródła JSON
         */

        Object obj = new JSONParser().parse(new FileReader("JSONosoby.json"));
        JSONObject mojobj = (JSONObject) obj;
        String firtName = (String) mojobj.get("firstName");
        String lastName = (String) mojobj.get("lastName");

        System.out.printf("Imię: %s, Nazwisko: %s\n",firtName,lastName);

        long age = (long) mojobj.get("age");
        System.out.printf("Wiek: %d lat/a\n",age);

        Map address = ((Map)mojobj.get("address"));
        Iterator<Map.Entry> itr1 = address.entrySet().iterator();
        while (itr1.hasNext()){
            Map.Entry pair = itr1.next();
            System.out.printf("%s: %s\n",pair.getKey(),pair.getValue());
        }

        JSONArray jsontab = (JSONArray) mojobj.get("phone");
        Iterator itr2 = jsontab.iterator();

        while (itr2.hasNext()){
            itr1 = ((Map)itr2.next()).entrySet().iterator();
            while (itr1.hasNext()){
                Map.Entry pair = itr1.next();
                System.out.printf("%s: %s\n",pair.getKey(),pair.getValue());
            }
        }



    }
}
