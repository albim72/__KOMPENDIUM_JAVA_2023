public class Main {
    public static void main(String[] args) {

        Integer[] a = {233,45,6,78,9,42,31,10};
        Character[] c = {'x','y','z','s','g','b','e'};
        String[] s = {"Zielony","Las","Morze","Wąwóz","Płaskowyż","Brunatny"};

        System.out.println("sotrowanie Integer array:");
        sort_generic(a);

        System.out.println("sotrowanie Character array:");
        sort_generic(c);

        System.out.println("sotrowanie String array:");
        sort_generic(s);


    }

    public static <T extends Comparable<T>> void sort_generic(T[] a)
    {
        for(int i=0;i<a.length-1;i++){
            for(int j=0;j<a.length-i-1;j++){
                if(a[j].compareTo(a[j+1])>0){
                    swap(j,j+1,a);
                }
            }
        }

        //printowanie elemenetów
        for(T i:a)
        {
            System.out.print(i+", ");

        }
        System.out.println("");
    }
    public static <T> void swap(int i,int j,T[] a){
        T t = a[i];
        a[i] = a[j];
        a[j] = t;
    }
}