package marcin.com;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) {
        List<String> imie = Arrays.asList("Tomek","Ania","Lucy","Olaf","Konrad","Tekla");

        Predicate<String> p = (s) -> s.startsWith("T");

        for (String st:imie){
            if(p.test(st))
                System.out.println(st);
        }

    }
}
