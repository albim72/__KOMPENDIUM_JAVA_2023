import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

class Student{
    int rollno;
    String name,address;

    public Student(int rollno, String name, String address) {
        this.rollno = rollno;
        this.name = name;
        this.address = address;
    }

    @Override
    public String toString() {
        return this.rollno + " " + this.name + " " + this.address;
    }
}

class Sortbyname implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        return o1.name.compareTo(o2.name);
    }
}

public class Main {
    public static void main(String[] args) {

        ArrayList<Student> ar = new ArrayList<>();
        ar.add(new Student(456,"Janek","Kraków"));
        ar.add(new Student(123,"Olga","Kraków"));
        ar.add(new Student(674,"Janek","Kielce"));
        ar.add(new Student(129,"Anna","Łódź"));
        ar.add(new Student(333,"Olga","Gdańsk"));

        System.out.println("nieposortowane...");

        for(int i=0;i<ar.size();i++){
            System.out.println(ar.get(i));
        }

        Collections.sort(ar,new Sortbyname());
        System.out.println("postorwane po imieniu: ");

        for(int i=0;i<ar.size();i++){
            System.out.println(ar.get(i));
        }

    }
}