import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {

        Map<String,Integer> mojamapa = new HashMap<>();
        mojamapa.put("a",43443);
        mojamapa.put("x",65656);
        mojamapa.put("y",21221);
        mojamapa.put("z",76677);
        mojamapa.put("z",765667);

        for (Map.Entry<String,Integer> me:mojamapa.entrySet()){
            System.out.print(me.getKey() + ": ");
            System.out.println(me.getValue());
        }

        Map<Integer,String> miasta = new HashMap<>();
        miasta.put(3,"Warszawa");
        miasta.put(13,"Gdańsk");
        miasta.put(23,"Wrocław");
        miasta.put(33,"Łódź");


        System.out.println("mapa: " + miasta);
        miasta.put(23,"Poznań");
        System.out.println("mapa: " + miasta);

        miasta.remove(3);
        System.out.println("mapa: " + miasta);


    }
}