import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {

        LinkedList<String> zawody  = new LinkedList<>();

        zawody.add("Boston Marathon");
        zawody.add("Maraton Warszawski");
        zawody.addFirst("Tatra Sky Marathon");
        zawody.addLast("Gorce Ultra Trail");
        zawody.add(3,"Bieg Rzeźnika");


        System.out.println(zawody);

        zawody.remove("Bieg Rzeźnika");
        zawody.remove(0);

    }
}