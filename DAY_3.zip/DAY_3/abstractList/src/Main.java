import java.util.AbstractList;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        AbstractList<String> abslista = new ArrayList<>();
        abslista.add("Marcin");
        abslista.add("Kraków");
        abslista.add("2222");
        abslista.add("78.99");
        abslista.add("Kraków");
        abslista.add("aaaaaaa");

        System.out.println("Lista abstrakcyjna: " + abslista);

        abslista.remove(2);

        System.out.println("Końcowa Lista abstrakcyjna: " + abslista);

        int lindex = abslista.lastIndexOf("Kraków");
        System.out.println(lindex);
    }
}