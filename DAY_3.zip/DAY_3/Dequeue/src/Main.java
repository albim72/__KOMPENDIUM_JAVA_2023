import java.util.ArrayDeque;
import java.util.Deque;

public class Main {
    public static void main(String[] args) {

        Deque<Integer> deq = new ArrayDeque<>();
        deq.addFirst(23);
        deq.add(34);
        deq.addLast(555);
        System.out.println(deq);

        int lewy = deq.removeFirst();
        int prawy = deq.removeLast();
        System.out.println("pierwszy: " + lewy + ", ostatni: "  + prawy);
    }
}