import java.util.AbstractSequentialList;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {

        AbstractSequentialList<Integer> absseq = new LinkedList<>();
        absseq.add(5);
        absseq.add(123);
        absseq.add(-34);
        absseq.add(0);
        absseq.add(56);

        System.out.println(absseq);
    }
}