import java.util.AbstractQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class Main {
    public static void main(String[] args) {

        AbstractQueue<Integer> AQ = new LinkedBlockingDeque<>();

         AQ.add(10);
         AQ.add(15);
         AQ.add(66);
         AQ.add(88);
         AQ.add(101);
         AQ.add(674);
         AQ.add(0);

        System.out.println(AQ);

        int head = AQ.remove();

        System.out.println("head: " + head);

        AQ.clear();
        System.out.println(AQ);
    }
}