import java.util.HashMap;

public class Main {
    public static void main(String[] args) {

        HashMap<String,Integer> mmap = new HashMap<>();
        mmap.put("a1",56);
        mmap.put("a2",64);
        mmap.put("a3",23);
        mmap.put("a4",52);
        mmap.put("a5",13);

        System.out.println(mmap);
    }
}