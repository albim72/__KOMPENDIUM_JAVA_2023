public interface IZwierz {
    public int pokazliczbenog();
    public void jakiodglos();
    public void jakiesrodowisko();
}
