public class Main {
    public static void main(String[] args) {


        Pajak tarantula = new Pajak("Pająk","Tarantula",8,"dowolne miejsce...",
                "inne żywe stworzenia","ciche pełza...","szklane terrarium 40cm x 60cm x 60cm");

        Pies buldog = new Pies("Pies","Buldog angielski",4,"wszędzie gdzie się wciśnie...",
                "mięso i dodatki","szczekanie i inne...","materacu 120cm x 90 cm");

        System.out.println("__________________________________________________________");
        System.out.println("na początek pająk...");
        System.out.println(tarantula.jakieJedzenie());
        System.out.println("Liczba odnóży: " + tarantula.pokazliczbenog());
        tarantula.jakiodglos();
        tarantula.jakiesrodowisko();

        System.out.println("__________________________________________________________");
        System.out.println("i pies...");
        System.out.println(buldog.jakieJedzenie());
        System.out.println("Liczba nóg: " + buldog.pokazliczbenog());
        buldog.jakiodglos();
        buldog.jakiesrodowisko();

    }
}