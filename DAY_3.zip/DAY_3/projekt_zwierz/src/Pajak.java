public class Pajak extends AZwierz{

    public String terrarium;
    public Pajak(String gatunek, String rodzaj, Integer liczbanog, String srodowisko, String rodzajPokarmu, String odglos,
                 String terrarium) {
        super(gatunek, rodzaj, liczbanog, srodowisko, rodzajPokarmu, odglos);
        this.terrarium = terrarium;
    }

    @Override
    public String jakieJedzenie() {
        return rodzajPokarmu;
    }

    @Override
    public int pokazliczbenog() {
        return liczbanog;
    }

    @Override
    public void jakiodglos() {
        System.out.printf("%s %s %s",gatunek,rodzaj,odglos);
    }

    @Override
    public void jakiesrodowisko() {
        System.out.printf("%s, w domu mieszka w %s",srodowisko,terrarium);
    }
}
