import com.sun.jdi.request.StepRequest;

public abstract class AZwierz implements IZwierz{

    protected String gatunek;
    protected String rodzaj;
    protected Integer liczbanog;
    protected String srodowisko;
    protected String rodzajPokarmu;
    protected String odglos;

    public AZwierz(String gatunek, String rodzaj, Integer liczbanog, String srodowisko, String rodzajPokarmu, String odglos) {
        this.gatunek = gatunek;
        this.rodzaj = rodzaj;
        this.liczbanog = liczbanog;
        this.srodowisko = srodowisko;
        this.rodzajPokarmu = rodzajPokarmu;
        this.odglos = odglos;
    }

    private void info(){
        System.out.println("Nowy zwierzak!");
    }

    public abstract String jakieJedzenie();
}
