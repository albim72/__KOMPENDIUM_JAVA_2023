public class Pies extends AZwierz{

    public String materac;
    public Pies(String gatunek, String rodzaj, Integer liczbanog, String srodowisko, String rodzajPokarmu, String odglos,
                String materac) {
        super(gatunek, rodzaj, liczbanog, srodowisko, rodzajPokarmu, odglos);
        this.materac = materac;
    }

    @Override
    public String jakieJedzenie() {
        return rodzajPokarmu;
    }

    @Override
    public int pokazliczbenog() {
        return liczbanog;
    }

    @Override
    public void jakiodglos() {
        System.out.printf("%s %s %s",gatunek,rodzaj,odglos);
    }

    @Override
    public void jakiesrodowisko() {
        System.out.printf("%s, w domu śpi na: %s",srodowisko,materac);
    }
}
