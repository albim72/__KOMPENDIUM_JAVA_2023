public class Main {

    static void fun() throws IllegalAccessException
    {
        System.out.println("wnętrze funkcji fun()");
        throw new IllegalAccessException("informacja abc");
    }

    public static void main(String[] args) {

        try{
            fun();

        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}