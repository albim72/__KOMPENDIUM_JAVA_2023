import java.time.DayOfWeek;
import java.util.EnumMap;

public class Main {
    public static void main(String[] args) {

        EnumMap<Dni,String> kalendarium = new EnumMap<>(Dni.class);
        kalendarium.put(Dni.PONIEDZIALEK,"pocztek pracy...");
        kalendarium.put(Dni.WTOREK,"praca, trening");
        kalendarium.put(Dni.SRODA,"praca,dentysta");
        kalendarium.put(Dni.CZWARTEK,"praca,trening");
        kalendarium.put(Dni.PIATEK,"praca, warsztaty");
        kalendarium.put(Dni.SOBOTA,"rower, pływalnia");
        kalendarium.put(Dni.NIEDZIELA,"wyjazd");


        System.out.println(kalendarium);
        System.out.println(Dni.PIATEK);
        System.out.println(kalendarium.get(Dni.PIATEK));

        System.out.println(kalendarium.keySet());
    }
}