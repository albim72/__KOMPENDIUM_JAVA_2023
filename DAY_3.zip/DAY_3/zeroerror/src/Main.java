public class Main {


    static double dzielprzezzero(int a,int b){
        double i = a/b;
        return i;
    }


    static double policzDzielenie(int a, int b){
        double wynik = 0;
        try {
            wynik = dzielprzezzero(a,b);
        }
        catch (NumberFormatException ex){
            System.out.println("nie dziel przez 0!");
        }
        return wynik;
    }

    public static void main(String[] args) {

        int a = 90;
        int b=0;
//        double w2 = policzDzielenie(a,b);
//        System.out.println(w2);

        try {
            double w = policzDzielenie(a,b);
            System.out.println(w);
        }
        catch (ArithmeticException ex){
            System.out.println(ex.getMessage());
        }
    }
}