import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {

        Set<String> mojz = new HashSet<>();
        mojz.add("Polska");
        mojz.add("Francja");
        mojz.add("Polska");
        mojz.add("Grecja");
        mojz.add("Polska");
        mojz.add("Szwajcaria");

        System.out.println(mojz);

        mojz.addAll(Arrays.asList(new String[]{"Norwegia","Finlandia","Hiszpania"}));

        System.out.println(mojz);
    }
}