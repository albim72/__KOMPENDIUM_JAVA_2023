import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class Main {
    public static void main(String[] args) {

        try {
            String a = null;
            System.out.println(a.charAt(0));
        }catch(NullPointerException e){
            System.out.println(e.getMessage());
        }

        System.out.println("_____________________________________");

        try {
            String a = "to jest bardzo ważny i specjalny tekst który poddamy analizie....";
            char c = a.charAt(80);
            System.out.println(c);
        }catch (StringIndexOutOfBoundsException e){
            System.out.println(e.getMessage());
        }

        System.out.println("_____________________________________");

        try {
            File file = new File("C://Temp//takie200.txt");
            FileReader fr = new FileReader(file);
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}