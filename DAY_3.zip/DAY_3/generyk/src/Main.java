class Test<T>
{
    T obj;

    public Test(T obj) {
        this.obj = obj;
    }

    public T getObj() {
        return obj;
    }
}

public class Main {
    public static void main(String[] args) {
        Test<Integer> iObj = new Test<>(23);
        System.out.println(iObj.getObj());

        Test<String> sObj = new Test<>("miasto Kraków");
        System.out.println(sObj.getObj());

    }
}