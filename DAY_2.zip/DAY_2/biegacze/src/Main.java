public class Main {
    public static void main(String[] args) {

        Biegacz b1 = new Biegacz("piwne",true,"Olga","Kot","Rzeszów",
                167.0,58.0,29,"K",567,"Tatra Sky Marathon",46.0);

        System.out.println(b1.informacja());
        b1.daneOsoby();
        System.out.println("Współczynnik BMI: " + b1.policzBMI());
        System.out.println("Średnia prędkość biegu: " + b1.avg_v(15.6) + " km/h");
    }
}