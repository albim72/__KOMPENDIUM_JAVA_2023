public class Main {
    public static void main(String[] args) {

        Prostokat pr = new Prostokat(4.6,8.8);
        System.out.println("wynik = " + pr.policzPole());

        Trojkat tr = new Trojkat(6.6, 8.9);
        System.out.println("wynik = " + tr.policzPole());

        Trapez trp = new Trapez(8.2,6.1,5);
        System.out.println("wynik = " + trp.policzPole());

        Kolo kl = new Kolo(5.5);
        System.out.println("wynik = " + kl.policzPole());
    }
}