public abstract class Figura {

    protected double a;
    protected double b;


    public Figura(double a) {
        this.a = a;
        this.info();
    }

    public Figura(double a, double b) {
        this.a = a;
        this.b = b;
        this.info();
    }

    public void info(){
        System.out.println("stworzono figurę płaską...");
    }

    public abstract double policzPole();
}
