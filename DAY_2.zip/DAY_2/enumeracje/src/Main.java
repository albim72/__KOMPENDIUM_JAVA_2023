enum Color {
    RED,GREEN,YELLOW
}

enum Day{
    MON,WT,SR,CZW,PT,SOB,NDZ,ERROR
}

public class Main {

    Day day;

    public Main(Day day){this.day = day;}

    public void dobrydzien(){
        switch (day){

            case MON:
                System.out.println("Poniedziałek i do pracy...");
                break;
            case WT:
                System.out.println("Wtorek...");
                break;
            case SR:
                System.out.println("Środa - środek tygodnia");
                break;
            case CZW:
                System.out.println("Czwartek pełen pracy");
                break;
            case PT:
                System.out.println("Piątek i blisko weekend");
                break;
            case SOB:
                System.out.println("Sobota i odpoczynek");
                break;
            case NDZ:
                System.out.println("Niedziela...");
                break;

            default:
                System.out.println("taki dzień nie istnieje!");
                break;

        }
    }

    public static void main(String[] args) {

        Color c1 = Color.RED;
        System.out.println(c1);

        String dayofweek = "ERROR";
        Main m1 = new Main(Day.valueOf(dayofweek));
        m1.dobrydzien();

        Color koltab[] = Color.values();
        for(Color col:koltab)
        {
            System.out.println(col + " przy indeksie " + col.ordinal());
        }

    }
}