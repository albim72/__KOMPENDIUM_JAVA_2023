import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {

        Set<String> mojSet = new HashSet<>();
        mojSet.add("abc");
        mojSet.add("abc");
        mojSet.add("xyz");
        mojSet.add("blabla");
        System.out.println(mojSet);

        Set<Integer> numb = new HashSet<>();
        numb.add(44);
        numb.add(44);
        numb.add(3);
        numb.add(7);

        System.out.println(numb);
    }
}