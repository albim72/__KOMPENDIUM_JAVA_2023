import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        List<Integer> l1 = new ArrayList<>();
        l1.add(0,1);
        l1.add(1,56);
        l1.add(122);
        l1.add(1,88);
        System.out.println(l1);

        List<Integer> l2 = new ArrayList<>();
        l2.add(33);
        l2.add(12);
        l2.add(32);

        l1.addAll(1,l2);
        System.out.println(l1);

        l1.remove(1);
        System.out.println(l1);

        System.out.println(l1.get(3));

        l1.set(0,44);
        System.out.println(l1);

        int index = l1.indexOf(4);
        System.out.println("indeks elementu 4: " + index);

        int lastIndex = l1.lastIndexOf(44);
        System.out.println(lastIndex);

    }
}